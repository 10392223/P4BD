# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 20:09:46 2018

@author: Martin PC
"""
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import statsmodels.formula.api as sm




#read in csv to df
df = pd.read_csv('changes.csv')
#investigate df
df.head()
#some erroneous columns in dataset, drop them
df= df.drop(['Unnamed: 6', 'Unnamed: 7', 'Unnamed: 8', 'Unnamed: 9', 'Unnamed: 10'], axis =1)


#merging date-time columns to create new date_time column, as will base some calcs later on this
df['date_time'] = df['date'] + ' ' + df['time']
#needed to reformat this column to make sure dates were in correct format.
#wasn't sure how to test these Timestamp dates.
df['date_time']= pd.to_datetime(df['date_time'], format='%d/%m/%Y %H:%M:%S')
#create hour, day name of commit using the newly created date_time column
#tested these in test file
df['hour_of_commit'] = df.date_time.dt.hour
df['day_of_commit'] = df.date_time.dt.weekday_name

#group the rows by author to see overall list of commits per author
commits_per_author = df.groupby(['author']).size().sort_values(ascending=False)
commits_per_author = pd.DataFrame(commits_per_author)


#group by day of commit to see distribution
days = df.groupby(['day_of_commit']).size().sort_values(ascending=False)
#coerces this to a data frame so I can test easily
days = pd.DataFrame(days)
  
#create a crosstab of author vs day_of_commit to see if any particular employee is doing anything strange
authors_ct_days = pd.crosstab(df['author'], df['day_of_commit'])
authors_ct_days = pd.DataFrame(authors_ct_days)

#create a crosstab of author vs hour_of_commit to see if any particular employee is doing work out of hours
authors_ct_hours = pd.crosstab(df['author'], df['hour_of_commit'])
authors_ct_hours = pd.DataFrame(authors_ct_hours)

#create a df to analyse how long each person has worked there, and allow us to see if someone has done more work relative to days employed
#groupby author and max and min dates
date_range_author = df.groupby('author').date_time.agg(['min', 'max'])
#create df from this result
dates_range_calc = pd.DataFrame(date_range_author)
#create time employed col by subtracting min date from max
dates_range_calc['time_employed'] = dates_range_calc['max'] - dates_range_calc['min']
#extract days variable from this calculatiom
dates_range_calc['days_worked'] = dates_range_calc.time_employed.dt.days
#work out commits per day by divided col from above df with days worked
dates_range_calc['commits_per_day'] = commits_per_author[0]/dates_range_calc['days_worked'] 

#regression model. See my word document for commentary
#calculate dummy variable for day of commit, avoid dummy variable trap by dropping one
dummies = pd.get_dummies(df['day_of_commit'],drop_first=True)
dummies = pd.DataFrame(dummies)
#concatenate dummy variables with df and drop day of commit variable it replaced
model = pd.concat([df, dummies], axis=1)      
model.drop(['day_of_commit'], inplace=True, axis=1)
#set up df for dep vs ind vars and then fit model (see word for discussion of specifics)
df_ols1 = pd.DataFrame({"A": model['number_of_lines'], "B": model['hour_of_commit'], "C": model['Monday'], "D": model['Tuesday'], "E":model['Wednesday'], "F":model['Thursday'] })
result1 = sm.ols(formula="A ~ B + C + D + E + F", data=df_ols1).fit()

#decided to construct a final model with comment length perhaps being an indicator of "effort" in work
#coerce comment to native string dtype
model['comment'] = model['comment'].astype(str)
#calc len of string, I test this in testing module
model['comment_length'] = model['comment'].apply(len)
#run new model (see word for desc)
df_ols2 = pd.DataFrame({"A": model['comment_length'], "B": model['hour_of_commit'], "C": model['Monday'], "D": model['Tuesday'], "E":model['Wednesday'], "F":model['Thursday'] })
result2 = sm.ols(formula="A ~ B + C + D + E + F ", data=df_ols2).fit()





#store prints, vizs in here so they don't appear during testing
if __name__ == '__main__':
    #boxplot of distribution of hours
    sns.set(style="whitegrid")
    sns.boxplot(x=df['hour_of_commit'])
    #histogram of dist of hours  
    plt.hist(df['hour_of_commit'].dropna(), bins=12, color='c', edgecolor='b', alpha=0.9)
    plt.axvline(df['hour_of_commit'].mean(), color='k', linestyle='dashed', linewidth=1)
       
    #prints commits per author table
    print(commits_per_author)
    
    #print days table
    print(days)
    #prints ct authors vs days
    print(authors_ct_days)
    
    #prints ct authors vs hours
    print(authors_ct_hours)
    
    #print date ranges df
    print(dates_range_calc)
    #show three employees we're interested in
    dates_range_calc.loc[['Thomas', 'Jimmy', 'Vincent'],:]
    
    ##regression views
    #to see dummy variables worked
    dummies.head()
    
    #model1 view
    model.head()
    
    #summary of model1
    result1.summary()
    
    #summary of model2
    result2.summary()

        

    