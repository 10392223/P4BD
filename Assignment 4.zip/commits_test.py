import unittest
from commit import get_commits, read_file
from commits_stats import *

class TestCommits(unittest.TestCase):

        
    def setUp(self):
        
                
        self.data = read_file('changes_python.log')
        
        
        
    def test_number_of_lines(self):
        self.assertEqual(5255, len(self.data))

    def test_number_of_commits(self):
        commits = get_commits(self.data)
        self.assertEqual(422, len(commits))
        self.assertEqual('Thomas', commits[0].author)
        self.assertEqual('Jimmy', commits[420].author)
        self.assertEqual(['FTRPC-500: Frontier Android || Inconsistencey in My Activity screen',
                'Client used systemAttribute name="Creation-Date" instead of versionCreated as version created.'],
                commits[24].comment)
        self.assertEqual(['M /cloud/personal/client-international/android/branches/android-15.2-solutions/libs/model/src/com/biscay/client/android/model/util/sync/dv/SyncAdapter.java'],
                commits[20].changed_path)
    
    #test new columns days/hours
    def testDaysHoursColumns(self):
        
        #checked date from first row on google for day of week, took hour from date_time
        self.assertEqual(16, df['hour_of_commit'][0] )
        self.assertEqual('Friday', df['day_of_commit'][0])
    
    #test commits per author output
    def testCommitsPerAuthor(self):
        
        
        #check if commits for Jimmy is 152
        self.assertEqual(152, commits_per_author[0][1])
     
        #test dist of days data 
    def testDayDist(self):
        
        
        self.assertEqual(95, days[0][1])
      
        #test crosstab of authors * day of commit
    def testAuthorsCrossDays(self):
        
        
        self.assertEqual(1, authors_ct_days['Monday'][1])
      
        #test crosstab of authors * hour of commit
    def testAuthorsCrossHours(self):
        
        
        self.assertEqual(3, authors_ct_hours[13.0][0])
        
        #test average committs per day data
    def testAverageCommitsPerDay(self):
        
        
        self.assertEqual(1.1428571428571428, dates_range_calc['commits_per_day'][5])
        
        #test dummy variable worked for modelling
    def testDummyVariable(self):
    
        
        #test first row, this is a friday so monday variable should be 0 = false
        self.assertEqual(0, dummies['Monday'][0])
        
        #test model df
    def testModelDF(self):
                
        self.assertEqual(0, model['Monday'][0])
       
        #test comment length calc
    def testCommentLen(self):
                 
        self.assertEqual(34, model['comment_length'][0])
        
if __name__ == '__main__':
    unittest.main()
